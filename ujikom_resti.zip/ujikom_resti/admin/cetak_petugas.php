<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<body id="page-top">

          <div class="card shadow mb-4">
            <div class="card-header py-3">
              
            </div>
            <div class="card-body">
            <h3 class="m-0 font-weight-bold text" align="center">UJI KOMPETENSI SMK SANGKURIANG 1 CIMAHI </h3>
            <h4 class="m-0 font-weight-bold text" align="center">REKAYASA PERANGKAT LUNAK </h4>
            <h6 class="m-0 font-weight-bold text" align="center">TAHUN AJARAN 2022/2023</h6>
            <br><br><hr>
            <h6 class="m-0 font-weight-bold text" align="center">Laporan Petugas</h6>
            <br><hr>

              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  
                    <tr>
                      <th>ID</th>
                      <th>Tanggal Pengaduan</th>
                      <th>NIK</th>
                      <th>Isi Laporan</th>
                      <th>Foto</th>
                      <th>Status</th>
                    </tr>
                  
                  <?php
                  
                  require '../koneksi.php';
                  $sql=mysqli_query($koneksi, "SELECT * FROM petugas");
                //   $sql= mysqli_query($koneksi, "SELECT * FROM pengaduan WHERE status='proses'");
                  while  ($data=mysqli_fetch_array($sql)){

                   ?> 
                  <tbody>
                    <tr>
                      <td><?php echo $data['id_petugas']; ?></td>
                      <td><?php echo $data['nama_petugas']; ?></td>
                      <td><?php echo $data['username']; ?></td>
                      <td><?php echo $data['password']; ?></td>
                      <td><?php echo $data['telp']; ?></td>
                      <td><?php echo $data['level']; ?></td>
                      
                    </tr>
                    
                  </tbody>
                  <?php } ?>
                </table>
                
              </div>
              <br>
                <br>
                <h6 class="m-0 font-weight-bold text-primary" align="right">Bandung, <?php echo date('d  m Y'); ?></h6>
                <h6 class="m-0 font-weight-bold text-primary" align="right">Petugas,</h6>
                <br><br><br><br>
                <br>
                <br>
                <h6 class="m-0 font-weight-bold text-primary" align="right"><?php echo $_SESSION ['nama']; ?></h6>
            </div>
          </div>

        </div>
      </div>
    
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
        
          </div>
        </div>
      </footer>

    </div>
  </div>
  
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
