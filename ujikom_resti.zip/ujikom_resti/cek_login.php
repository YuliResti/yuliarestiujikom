<?php
include 'koneksi.php';
$user= $_POST['username'];
$pass=$_POST['password'];
$sql=mysqli_query($koneksi, "SELECT * FROM masyarakat WHERE username= '$user'");
$cek=mysqli_num_rows($sql);

        if($cek){
        $data = mysqli_fetch_array($sql);
        session_start();
        $_SESSION['nama'] = $user;
        $_SESSION['nik'] =  $data['nik'];
        header('location:masyarakat.php');   
        }
        else
        {
            ?>
    <script type="text/javascript">
        alert ('Data berhasil disimpan, Silahkan gunakan untuk login');
        windows.location="index.php";
    </script>
<?php
        }
        ?>