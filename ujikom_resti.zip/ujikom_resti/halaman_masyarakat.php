<?php
session_start();
if(isset($_GET['url'])){

    $url=$_GET['url'];
    
    switch($url){
        
        case 'tulis_pengaduan';
        include 'tulis_pengaduan.php';
        break;
    
        case 'lihat_pengaduan';
        include 'lihat_pengaduan.php';
        break;
        
        case 'detail_pengaduan';
        include 'detail_pengaduan.php';
        break;

        case 'lihat_tanggapan';
        include 'lihat_tanggapan.php';
        break;
    }
}
else{
    ?>
    Selamat datang di halaman pengaduan masyarakat yang digunakan untuk melaporkan
    pelanggaran atau penyimpangan atau keluhan mengenai kejadian yang terjadi pada
    masyarakat <br><br>
    Anda Login Sebagai : <h2><b>
        <?php 
        if(isset($_SESSION['nama'])){
            echo $_SESSION['nama'];
        }
       
         ?>
<?php }
?>