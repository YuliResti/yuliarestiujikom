 <?php
$koneksi=mysqli_connect('localhost','root','','resti_praukk_rpl2');
?>



