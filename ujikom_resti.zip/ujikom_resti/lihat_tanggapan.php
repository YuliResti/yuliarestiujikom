<?php
include("css.php");
?>

<!DOCTYPE html>
<html lang="en">

<body id="page-top">

<div class="card shadow">
    <div class="card-header">
        Detail Pengaduan
    </div>
    <div class="card-body">
    <div class="form-group cols-sm-6">
    <a href="?url=lihat_pengaduan" class="btn btn-primary btn-icon-split">
        <span class="icon text-white-50">
            <i class="fas fa-arrow-Left"></i>
</span>
<span class="text">Kembali</span>
</a>

    
        <form action="" method="post" class="form_horizontal" enctype="multipart/form-data">

            <?php
            include'koneksi.php';
            $sql=mysqli_query($koneksi, "SELECT * FROM pengaduan, tanggapan WHERE tanggapan.id_pengaduan='$_GET[id]' AND
            tanggapan.id_pengaduan=pengaduan.id_pengaduan");
            $cek=mysqli_num_rows($sql);
                if ($cek<1)//jika tidak ditemukan
                {
                    echo "<font color='red'>Mohon bersabar, pengaduan belum ditanggapi</font>";
                } else {

                }
                if ($data=mysqli_fetch_array($sql))
                {       
            ?>
            <div class="form-group cols-sm-6">
                <label>Tanggal Tanggapan</label>
                <input type="text" name="tgl_pengaduan" value="<?php echo $data['tgl_tanggapan']; ?>" class="form-control"readonly>
            </div>
            
            <div class="form-group cols-sm-6">
                <label>Tulis Laporan</label>
                <textarea class="form-control" rows="7" name="isi_laporan" readonly=""><?php echo $data['isi_laporan']; ?>
            </textarea>
            </div>

            <div class="form-group cols-sm-6">
                <label>Tulis Tanggapan</label>
                <textarea class="form-control" rows="7" name="isi_laporan" readonly=""><?php echo $data['tanggapan']; ?>
            </textarea>
            </div>
            </div>

            <?php } ?>

            </form>
        </div>
        </div>
</body>

</html>