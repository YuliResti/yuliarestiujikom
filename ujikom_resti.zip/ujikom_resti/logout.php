<?php
// untuk memulai eksekusi session pada server 
session_start();
unset($_SESSION['nama']);
session_destroy();
header('location:index.php');
?>